library(tidyverse)
library(factoextra)
library(cluster)
library(NbClust)
library(fpc) 
library(dendroextras)
library(dendextend) 
library(mclust) 
library(dbscan)
library(dplyr)
library(magrittr)
library(arulesCBA)
library(arulesViz)


#install.packages("factoextra")

Data<-read.csv("http://www.webpages.uidaho.edu/~stevel/Datasets/Mt1t.mutate.csv",header=TRUE,sep=',')
Data<-Data[-c(1:3),]

dim(Data) 

for (i in 2:ncol(Data)){
  Data[is.na(Data[,i]),i]<-median(Data[,i],na.rm = TRUE)
}

Data1=as.matrix(sapply(Data[-1], as.numeric))
Data2<-as.data.frame(Data1[,apply(Data1,2,var,na.rm=TRUE) !=0])
Data2=cbind(Data$Group,Data1)
colnames(Data2)[1]<-"Group"
dim(Data2)


par(mfrow=c(1,2))
Data.s=scale(Data2)
Data.pca=prcomp(Data2[,-1],scale=FALSE)

Data.pca$rotation[1:5,1:5]

Data.sd=Data.pca$sdev
Data.var=Data.pca$sdev^2 
Data.var[1:10]


pve=Data.var/sum(Data.var)

which.max(cumsum(pve)[cumsum(pve)<0.95])
which.max(cumsum(pve)[cumsum(pve)<0.98])

cumsum(pve[100])

#fviz_screeplot(Data.pca,ncp=100,choice="eigenvalue")

plot(cumsum(pve),xlab="Principal Component", 
     ylab="Cumulative Proportion of variance explained",ylim=c(0,1),type='b')
biplot(Data.pca,arrow.len=0) # Arrow head length is suppressed to get rid of the errors of indeterminate angle
DataClasses<- factor(Data$Group)
plot(main="Different Groups",Data.pca$x[,1:100],col=DataClasses)

Datanew=Data.pca$x[,1:100]
Datanew.s=scale(Datanew)

set.seed(10)
fviz_nbclust(Datanew,kmeans,method="wss") 
fviz_nbclust(Datanew,kmeans,method="silhouette") 
fviz_nbclust(Datanew,kmeans,method="gap_stat") 
Data.nbclust<-Datanew %>%
  scale() %>%
  NbClust(distance="euclidean",min.nc=2,max.nc=8,method="complete",index="all")

pve=Data.var/sum(Data.var)

cumsum(pve[200])
fviz_screeplot(Data.pca,ncp=200,choice="eigenvalue")
plot(cumsum(pve),xlab="Principal Component", 
     ylab="Cumulative Proportion of variance explained",ylim=c(0,1),type='b')
biplot(Data.pca,arrow.len=0) # Arrow head length is suppressed to get rid of the errors of indeterminate angle
DataClasses1<- factor(Data$Group)
plot(main="Different Groups",Data.pca$x[,1:200],col=DataClasses1)


Datanew1=Data.pca$x[,1:200]
Datanew1.s=scale(Datanew)

set.seed(11)
fviz_nbclust(Datanew1,kmeans,method="wss") 
fviz_nbclust(Datanew1,kmeans,method="silhouette")
fviz_nbclust(Datanew1,kmeans,method="gap_stat")
Data.nbclust<-Datanew1 %>% 
  scale() %>%
  NbClust(distance="euclidean",min.nc=2,max.nc=8,method="complete",index="all")


set.seed(10)
km_100_2.fit=kmeans(Datanew,2,nstart=50)
attributes(km_100_2.fit)
km_100_2.fit$size
km_100_2.fit$tot.withinss
plotcluster(Datanew,km_100_2.fit$cluster)
fviz_cluster(km_100_2.fit,data=Datanew,ellipse.type="convex",palette="jco",ggtheme=theme_minimal())
set.seed(5)
km_100_8.fit=kmeans(Datanew,8,nstart=50)
attributes(km_100_8.fit)
km_100_8.fit$size
km_100_8.fit$tot.withinss
plotcluster(Datanew,km_100_8.fit$cluster)
fviz_cluster(km_100_8.fit,data=Datanew,ellipse.type="convex",palette="jco",ggtheme=theme_minimal())

set.seed(9)
km_200_2.fit=kmeans(Datanew1,2,nstart=50)
attributes(km_100_2.fit)
km_200_2.fit$size
km_200_2.fit$tot.withinss
plotcluster(Datanew1,km_200_2.fit$cluster)
fviz_cluster(km_200_2.fit,data=Datanew1,ellipse.type="convex",palette="jco",ggtheme=theme_minimal())
set.seed(8)
km_200_6.fit=kmeans(Datanew1,6,nstart=50)
attributes(km_200_6.fit)
km_200_6.fit$size
km_200_6.fit$tot.withinss
plotcluster(Datanew1,km_200_6.fit$cluster)
fviz_cluster(km_200_6.fit,data=Datanew1,ellipse.type="convex",palette="jco",ggtheme=theme_minimal())



par(mfrow=c(1,2))

Data.hc.ward=hclust(dist(Datanew,method="euclidean"),method="ward.D2")

plot(Data.hc.ward, main="Complete Linkage",xlab="",cex=.9)

rect.hclust(Data.hc.ward,k=2,border="orange")

Data.hc.ward=hclust(dist(Datanew,method="euclidean"),method="ward.D2")

plot(Data.hc.ward, main="Complete Linkage",xlab="",cex=.9)

rect.hclust(Data.hc.ward,k=8,border="red")

groups2=cutree(Data.hc.ward,2)
clusplot(Datanew,groups2,color=TRUE, shade = TRUE, labels=2, lines=0, main='Group segments')
groups8=cutree(Data.hc.ward,8)#Cut Tree into 8 clusters
clusplot(Datanew,groups8,color=TRUE, shade = TRUE, labels=2, lines=0, main='Group segments')

plotcluster(Datanew, groups2)
plotcluster(Datanew,groups8)

par(mfrow=c(1,3))
Data.fit<-Mclust(Datanew.s[,0:50])
summary(Data.fit); Data.fit$modelName ; Data.fit$G
fviz_mclust(Data.fit,"BIC",palette="jco")
fviz_mclust(Data.fit,"classification",geom="point",pointsize=1.5, palette="jco")
fviz_mclust(Data.fit,"uncertainty", palette="jco")

Data.fit1<-Mclust(Datanew1.s[,0:50])
summary(Data.fit1); Data.fit1$modelName ; Data.fit1$G
fviz_mclust(Data.fit1,"BIC",palette="jco")
fviz_mclust(Data.fit1,"classification",geom="point",pointsize=1.5, palette="jco")
fviz_mclust(Data.fit1,"uncertainty", palette="jco")


par(mfrow=c(1,2))
dbscan::kNNdistplot(Datanew,k=2)
abline(h=2, lty=2,col="red")
set.seed(123)

Data.db<-fpc::dbscan(Datanew,eps=1,50)
Data.db
fviz_cluster(Data.db,data=Datanew, stand=FALSE, ellipse=TRUE,show.clust.cent = TRUE,
             geon="point",palette="default", ggtheme=theme_minimal())



Data.group<-Data.frame(Datanew,km_100_8.fit$cluster)

colnames(Data.group)[101]<-"Group"
Data.group$Group<-factor(as.character(Data.group$Group))
write.csv(Data.group,"mitogroup_100_8.csv")
Data.group_200<-data.frame(Datanew,km_200_6.fit$cluster)

colnames(Data.group_200)[101]<-"Group"
Data.group_200$Group<-factor(as.character(Data.group_200$Group))
write.csv(Data.group,"mitogroup_200_6.csv")


set.seed(1234)
train_test_split=sample(1:2,dim(mito.group)[1],repl=T)
idx1<-train_test_split
train.mito<-mito.group[idx1==1,] #training set
test.mito<-mito.group[idx1==2,] #testing set
train.mito[,names(train.mito)] <- lapply(train.mito[,names(train.mito)] , factor)
train.mito <- as(train.mito, "transactions")

test.mito[,names(test.mito)] <- lapply(test.mito[,names(test.mito)] , factor)
test.mito <- as(test.mito, "transactions")

rules1 <- apriori(data = train.mito , parameter = list( supp = 0.001 , conf = 0.9))
rules1<-sort(rules1 , decreasing = TRUE , by = 'lift')

inspect(rules1[1:25])

plot(rules1, measure=c("support", "lift"), shading="confidence")
head(quality(rules1))
