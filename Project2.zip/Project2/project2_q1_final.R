library(dendroextras)
library(dendextend)
library(tidyverse)
library(mclust)
library(factoextra)
library(MVA)
library(circlize)
library(cluster)   #allow us to represent (with the aid of PCA) the cluster solution into 2 dimensions
library(NbClust) 
library(seriation)
##install.packages("factoextra")
mydata<-read.csv("https://raw.githubusercontent.com/sauchilee/Stat517/master/Data/World_Happiness_2015.csv")
attach(mydata)
dim(mydata)

row.names(mydata)<-mydata$Country
colnames(mydata)

mydata.n = mydata[,6:12]
mydata.ns=scale(mydata.n)
mydata.nd=dist(mydata.ns)

set.seed(4)
clust.out=kmeans(mydata.ns,3,nstart=20)
clust.out$withinss
#plot(mydata.ns, col=clust.out$cluster+1), main="K-Means Clustering Results with K=3", xlab="", ylab="", pch=20, cex=2) 
clustering1<-NbClust(mydata.ns, distance="euclidean", min.nc=2,max.nc=10, method="kmeans")
clustering2<-NbClust(mydata.ns, distance="euclidean", min.nc=2,max.nc=10, method="complete")
mydatadend=agnes(mydata.nd,diss=FALSE,metric="euclidian")
plot(mydatadend, main='Dendrogram') ## dendrogram

k.means.fit <- kmeans(mydata.ns, 3) # k = 4
attributes(k.means.fit)
# Centroids:
k.means.fit$centers
# Cluster size:
k.means.fit$size
#clusplot(mydata.ns, k.means.fit$cluster, main='2D representation of the Cluster',
         #color=TRUE, shade=TRUE,
         #labels=1, lines=0)


data.nc=Mclust(mydata.ns)
fviz_mclust(data.nc,"BIC",palette="jco")

hc.complete=hclust(dist(mydata.ns), method="complete")
hc.average=hclust(dist(mydata.ns), method="average")
hc.single=hclust(dist(mydata.ns), method="single")
par(mfrow=c(1,3))
plot(hc.complete,main="Complete Linkage", xlab="", sub="", cex=.3)
plot(hc.average, main="Average Linkage", xlab="", sub="", cex=.3)
#plot(hc.single, main="Single Linkage", xlab="", sub="", cex=.9)

#WORLD HAPPINESS 2016
data16<-read.csv("https://raw.githubusercontent.com/sauchilee/Stat517/master/Data/World_Happiness_2016.csv")
attach(data16)
dim(data16)
row.names(data16)<-data16$Country
colnames(data16)
data16.n=data16[,7:13]
data16.ns=scale(data16.n)
data16.nd=dist(data16.ns)

set.seed(2)
kmean16.out=kmeans(data16.ns,2,nstart=20)
#km.out$cluster
kmean16.out$withinss
plot(data16.ns, col=(kmean16.out$cluster+1), main="K-Means Clustering Results with K=2", xlab="", ylab="", pch=20, cex=2)

k_means<-NbClust(data16.ns, distance="euclidean", min.nc=2,max.nc=10, method="kmeans")
k_means<-NbClust(data16.ns, distance="euclidean", min.nc=2,max.nc=10, method="complete")
data16agg=agnes(data16.nd,diss=FALSE,metric="euclidian")
plot(data16agg, main='Dendrogram') ## dendrogram
k.means.fit <- kmeans(data16.ns, 4) # k = 4
attributes(k.means.fit)
# Centroids:
k.means.fit$centers
# Cluster size:
k.means.fit$size
clusplot(data.ns, k.means.fit$cluster, main='2D representation of the Cluster solution',
         color=TRUE, shade=TRUE,
         labels=2, lines=0)
data16.nc=Mclust(hapi2016.ns)

fviz_mclust(data16.nc,"BIC",palette="jco") 
hc.complete=hclust(dist(data16.ns), method="complete")
hc.average=hclust(dist(data16.ns), method="average")

par(mfrow=c(1,3))
plot(hc.complete,main="Complete Linkage", xlab="", sub="", cex=.3)
plot(hc.average, main="Average Linkage", xlab="", sub="", cex=.3)

###
data17=read.csv("https://raw.githubusercontent.com/sauchilee/Stat517/master/Data/World_Happiness_2016.csv")
dim(data17)
# TAKING OUT HAPPINESS INFORMATION FROM THE GIVEN DATASET FOR THE CLUSTERING ANALYSIS
row.names(data17)<-data17$Country
data17<-data17[,6:12]
data17.s=scale(data17)
data17.d=dist(data17.s)

data17.hc.s=hclust(data17.d,method="ward.D")
data17dend=as.dendrogram(data17.hc.s)
labels_colors(data17dend)<-as.numeric(as.factor(data17$Region[data17.hc.s$order]))
dend17=as.dendrogram(data17.hc.s)
plot(data17dend)

set.seed(123)
fviz_nbclust(data17.s,kmeans,method="silhouette")
fviz_nbclust(data17.s,kmeans,method="gap_stat")
fviz_nbclust(data17.s,kmeans,method="wss")
happy17data.nbclust<-data17 %>% #Using NbClust 
  scale() %>% NbClust(distance="euclidean",min.nc=2,max.nc=6,method="complete",index="all")
data17.k2sil<-kmeans(data17.s,centers=3,iter.max=50,nstart=25)
data17.k4gap<-kmeans(data17.s,centers=3,iter.max=50,nstart=25)

data17.mclust<-Mclust(data17.s)
summary(data17.mclust)
fviz_mclust(data17.mclust,"BIC",palette="jco") 
##seraition

data2017<-as.matrix(data17)
data2017<-data2017[sample(seq_len(nrow(x2017))),]
d2017<-dist(data2017)
t2017<-seriate(d2017,method="OLO")
pimage(d2017,main="Original")
pimage(d2017,t2017,main="ordered")
#get_order(t2017)


set.seed(50)
xdata2015<-as.matrix(mydata.n)
xdata2015<-xdata2015[sample(seq_len(nrow(xdata2015))),]
ddata2015<-dist(xdata2015)
odata2015<-seriate(ddata2015, method = "TSP")
pimage(ddata2015,main="Random")
pimage(ddata2015,odata2015,main="Reordered")


set.seed(50)
xdata2016<-as.matrix(data16.n)
xdata2016<-xdata2016[sample(seq_len(nrow(xdata2016))),]
dhapi2016<-dist(xdata2016)
ohapi2016<-seriate(dhapi2016, method = "TSP")
pimage(dhapi2016,main="Random")
pimage(dhapi2016,ohapi2016,main="Reordered")

