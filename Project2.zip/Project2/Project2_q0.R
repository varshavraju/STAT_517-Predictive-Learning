library(plyr) ; library(stringr) ; library(caret) ; library(car)
library(class) ; library(knitr) ; library(MASS) ; library(e1071)
library(glmnet) ; library(pls) ; library(mice)


##**1.Reading data into r and converting some variables into factors**


mydata=read.csv("http://www.webpages.uidaho.edu/~stevel/Datasets/salary_uk.csv") 
table(mydata$Category)
mydata$Title<- as.factor(mydata$Title)
mydata$FullDescription<- as.factor(mydata$FullDescription)
mydata$ContractType[mydata$ContractType=='']<-NA
mydata$ContractType <- as.factor(mydata$ContractType)
mydata$ContractTime[mydata$ContractTime=='']<-NA
mydata$ContractTime <- as.factor(mydata$ContractTime)
mydata$Category <- as.factor(mydata$Category)
mydata$SourceName <- as.factor(mydata$SourceName)
mydata$Company <- as.factor(mydata$Company)
mydata$LocationNormalized <- as.factor(mydata$LocationNormalized)
mydata<-subset(mydata,select = -c(SalaryRaw))  





mydata$Tlevel<-"Mid-Level"
for(i in 1:length(mydata$Title)){
  if(grepl('Director', mydata[i,3],ignore.case=TRUE)|grepl("Senior",mydata[i,2] , ignore.case = TRUE)| grepl("Manager",mydata[i,2] , ignore.case = TRUE) | grepl("Head",mydata[i,2] , ignore.case = TRUE) | 
     grepl("Chef",mydata[i,2] , ignore.case = TRUE) | grepl("Lead",mydata[i,2] , ignore.case = TRUE)){
    mydata$Tlevel [i]<- "Senior"
  }
  else if (grepl("Junior",mydata[i,2] ,ignore.case = TRUE) |
           grepl("Entry",mydata[i,2] , ignore.case = TRUE))
  {
    mydata$Tlevel[i]<- "Junior"
  }
  else{
    mydata$Tlevel[i]<- "Mid-Level"
  }
}



myurl<-'https://docs.google.com/spreadsheets/d/e/2PACX-1vQXzU41Zv3GwB5s_YJQsrLdSnMt2isMWj03ZZ910sLel_vL9ZtsyROewGegGZDkmwgYYa1FMw2tWzKl/pub?gid=1568496122&single=true&output=csv'
tee1 <- read.csv(url(myurl),header = FALSE)
tee<-as.vector(tee1[,'V1'])
for (i in 1:nrow(mydata)) {
  # get city name
  loc <- mydata$LocationNormalized[i]
  # find the first line in the tree in which that city name appears
  line.id <- which(grepl(loc, tee))[1]
  # use regular expressions to pull out the broad location
  r <- regexpr("~.+?~", tee[line.id])
  match <- regmatches(tee[line.id], r)
  # store the broad location
  mydata$Location[i] <- gsub("~", "", match)  #Error: replacement has length zero
}
mydata$Location <- as.factor(mydata$Location)
table(mydata$Location)
# label London as 1, non-London as 0
mydata$Location <- as.factor(ifelse(mydata$Location == "London", 1, 0)) 

#### **Since there are so many different companies. I have no idea how to aggregate them into levles. I just label Top 50 companies as 1, others as 0.**

company.counts <- summary(mydata$Company)
top.company <- names(company.counts[order(company.counts, decreasing= TRUE)][1:50])
mydata$TopCom <- factor(mydata$Company, levels=top.company)
mydata$TopCom[mydata$TopCom == ""] <-NA
mydata$TopCom <- as.factor(ifelse(is.na(mydata$TopCom), 0, 1))

#####**Creating an aggregate category: WhiteCollar=(Accounting, Engineering, Legal, IT, Cosultancy,HR)**
##### **WhiteCollar labels 1, others label 0**

mydata$WhiteCollar <- grepl('IT', mydata$Category) | grepl('Engineer', mydata$Category) |
  grepl('Finance', mydata$Category) | grepl('Legal', mydata$Category) | grepl('Consult', mydata$Category)|
  grepl('HR', mydata$Category)
mydata$WhiteCollar <- as.factor(ifelse(mydata$WhiteCollar == "TRUE", 1, 0))



sources.counts <- summary(mydata$SourceName)
top5.sources <- names(sources.counts[order(sources.counts, decreasing= TRUE)][1:5])
mydata$Top5Source <- factor(mydata$Source, levels=top5.sources)
mydata$Top5Source <- as.factor(ifelse(is.na(mydata$Top5Source), 0, 1))

mydata1<-subset(mydata,select = -c(Id,Title,FullDescription,LocationRaw,LocationNormalized,
                                 Company,Category,SourceName))

set.seed(2344)
n=10000
idx=sample(1:2,n,repl=T)
ss1<-mydata1[idx==1,]
ss_mod1=mice(ss1[, !names(ss1) %in% "SalaryNormalized"], 
             method = c("polyreg", "polyreg", "", "" , "", "", ""))
ss11<-cbind(complete(ss_mod1),SalaryNormalized=ss1[,'SalaryNormalized'])
ss2<-mydata1[idx==2,]
ss_mod2=mice(ss2[, !names(ss2) %in% "SalaryNormalized"], 
             method = c("polyreg", "polyreg", "", "" , "", "", ""))
ss22<-cbind(complete(ss_mod2),SalaryNormalized=ss2[,'SalaryNormalized'])
set.seed(1234)
n=10000
idx2=sample(1:2,n,repl=T)
mydata2=rbind(ss11,ss22)
mydata1.train<-mydata2[idx2==1,] #training set
mydata1.test<-mydata2[idx2==2,] #testing set

mydata.lm = lm(formula = SalaryNormalized ~ ., data = mydata1.train)
summary(mydata.lm)
lm_full <- mydata.lm # full model is the model just fitted
lm_null <- lm(SalaryNormalized ~ 1, data = mydata1.train)
# backward selection
step(lm_full, trace = F, scope = list(lower=formula(lm_null), upper=formula(lm_full)),
     direction = 'backward')
# forward selection
step(lm_null, trace = F, scope = list(lower=formula(lm_null), upper=formula(lm_full)),
     direction = 'forward')
##Predict using the model
lm.pred <- predict(mydata.lm , newdata = mydata1.test)
lm.result<-sqrt(mean((lm.pred - sdata1.test$SalaryNormalized)^2)) #RMSE value, the smaller the better
lm.result



log.lm <- lm(log(SalaryNormalized) ~., data=mydata1.train)
summary(log.lm)
log.pred <- predict(log.lm , newdata = mydata1.test)
log.result<-sqrt(mean((exp(log.pred) - mydata1.test$SalaryNormalized)^2)) #RMSE value, the smaller the better
log.result


#install.packages("glmnet")
library(glmnet)
#training set
x.train <- model.matrix(SalaryNormalized ~., data = mydata1.train)[, -1]
y.train <- mydata1.train$SalaryNormalized
# test set
x.test <- model.matrix(SalaryNormalized ~., data = mydata1.test)[, -1]
y.test <- mydata1.test$SalaryNormalized
# obtain best lambda
set.seed(1)
ri.lambda<- cv.glmnet(x.train, y.train, alpha = 0)
plot(ri.lambda)
# predict test set using best lambda and calculate RMSE
ridge.fit <- glmnet(x.train, y.train, alpha = 0)
plot(ridge.fit, xvar = "lambda", label = TRUE)
ridge.pred <- predict(ridge.fit, s = ri.lambda$lambda.min, newx = x.test)
ridge.result<-sqrt(mean((ridge.pred - y.test)^2))



set.seed(1)
lasso.fit=glmnet(x.train,y.train,alpha=1)
plot(lasso.fit)
# obtain best lambda
la.lambda=cv.glmnet(x.train,y.train,alpha=1)
plot(la.lambda)
# predict test set using best lambda and calculate RMSE
lasso.pred=predict(lasso.fit,s=la.lambda$lambda.min,newx=x.test)
lasso.RMSE<-sqrt(mean((lasso.pred - y.test)^2))

set.seed(2)
pcr.fit=pcr(SalaryNormalized~., data=mydata1.train,scale=TRUE, validation="CV")
summary(pcr.fit)
validationplot(pcr.fit,val.type="MSEP")
set.seed(1)
# predict test set using M=8 and calculate RMSE
pcr.pred=predict(pcr.fit,x.test,ncomp=8)
pcr.RMSE<-sqrt(mean((pcr.pred - y.test)^2))


result <- rbind(lm.RMSE,log.RMSE,ridge.RMSE,lasso.RMSE,pcr.RMSE,pls.RMSE)
rownames(result) <- (c('Linear Regression', 'Linear Regression(log transform)','Ridge Regression', 
                     'The Lasso','Principal Components Regression'))
colnames(result) <- 'RMSEResult'
round(result, 4)